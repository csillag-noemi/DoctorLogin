package com.example.doctorlogin

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class DatabaseHelper(private val context: Context):
            SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION){
    companion object {
        private const val DATABASE_NAME = "users.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "users"
        private const val COLUMN_ID = "id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_USERNAME TEXT NOT NULL," +
                "$COLUMN_PASSWORD TEXT NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val dropTableQuery = "DROP TABLE IF EXISTS $TABLE_NAME"
        db?.execSQL(dropTableQuery)
        onCreate(db)
    }

    fun insertUser(username: String, password: String): Long {
        if (username.isEmpty()) {
            throw IllegalArgumentException("Username cannot be empty.")
        }

        if (password.isEmpty()) {
            throw IllegalArgumentException("Password cannot be empty.")
        }

        return try {
            with(writableDatabase) {
                val values = ContentValues().apply {
                    put(COLUMN_USERNAME, username)
                    put(COLUMN_PASSWORD, password)
                }

                return insert(TABLE_NAME, null, values)
            }
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error inserting user: ${e.message}")
            -1
        }
    }

    fun readUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)

        return try {
            val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)
            val userExists = cursor.moveToFirst()
            cursor.close()
            userExists
        } catch (e: Exception) {
            Log.e("DatabaseHelper", "Error reading user: ${e.message}")
            false
        }
    }
}